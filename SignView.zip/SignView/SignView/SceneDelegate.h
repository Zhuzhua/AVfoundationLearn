//
//  SceneDelegate.h
//  SignView
//
//  Created by zhuzhihua on 2021/7/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

