//
//  ViewController.m
//  SignView
//
//  Created by zhuzhihua on 2021/7/23.
//

#import "ViewController.h"
#import "SignProcessView.h"
#import <Masonry/Masonry.h>
@interface ViewController ()
@property(nonatomic, strong) SignProcessView *signView;

@end

@implementation ViewController

- (SignProcessView *)signView{
    if (!_signView) {
        _signView = [[SignProcessView alloc]initWithFrame:CGRectZero];
        _signView.layer.cornerRadius = 3;
        _signView.layer.masksToBounds = YES;
        _signView.backgroundColor = [UIColor whiteColor];
    }
    return _signView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor grayColor];
    [self.view addSubview:self.signView];
    [self.signView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.inset(100);
        make.left.right.inset(0);
        make.height.mas_equalTo(281);
    }];
}


@end
