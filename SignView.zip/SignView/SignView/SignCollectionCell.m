//
//  SignCollectionCell.m
//  SignView
//
//  Created by zhuzhihua on 2021/7/23.
//

#import "SignCollectionCell.h"

@interface SignCollectionCell ()
@property(nonatomic, strong)UIImageView *iconImageView;
@property(nonatomic, strong)UIView *processView;
@property(nonatomic, strong)UIView *pointView;
@property(nonatomic, strong)UIImageView *markView;
@end

@implementation SignCollectionCell

- (UIView *)processView{
    if (!_processView) {
        _processView = [[UIView alloc]init];
        _processView.backgroundColor = [UIColor grayColor];
    }
    return _processView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame] ) {
        
    }
    return self;
}

- (void)setupUI{
    [self.contentView addSubview:self.processView];
    [self.contentView addSubview:self.iconImageView];
    [self.contentView addSubview:self.pointView];
}

@end
