//
//  SignProcessView.m
//  SignView
//
//  Created by zhuzhihua on 2021/7/23.
//

#import "SignProcessView.h"
#import <Masonry/Masonry.h>

#define KSCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define KSCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height

@interface SignProcessView ()<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>
@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) UICollectionView *signProcessView;
@property(nonatomic, strong) UIButton *signButton;
@property(nonatomic, strong) UILabel  *signCountLabel;
@end

static NSString *identify = @"signProcessIdntify";
@implementation SignProcessView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI{
    [self addSubview:self.titleLabel];
    [self addSubview:self.signCountLabel];
    [self addSubview:self.signButton];
    [self addSubview:self.signProcessView];

    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.inset(20);
        make.height.mas_equalTo(19);
    }];
    
    [self.signCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.inset(20);
        make.height.mas_equalTo(15);
    }];
    
    [self.signButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.inset(20);
            make.bottom.equalTo(self.signCountLabel.mas_top).offset(-10);
            make.height.mas_equalTo(45);
    }];
     
    [self.signProcessView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.inset(20);
            make.top.equalTo(self.titleLabel.mas_bottom).offset(15);
            make.height.mas_equalTo(138);
    }];
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.text = @"本月累计签到奖励";
        _titleLabel.font = [UIFont boldSystemFontOfSize:16];
        _titleLabel.textColor = [UIColor blackColor];
    }
    return _titleLabel;;
}

- (UIButton *)signButton{
    if (!_signButton) {
        _signButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _signButton.layer.cornerRadius = 3;
        _signButton.layer.masksToBounds = YES;
        _signButton.backgroundColor = [UIColor grayColor];
        [_signButton setTitle:@"已签到" forState:UIControlStateNormal];
        [_signButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    return _signButton;
}

- (UILabel *)signCountLabel{
    if (!_signCountLabel) {
        _signCountLabel = [[UILabel alloc]init];
        _signCountLabel.text = @"累计签到3天";
        _signCountLabel.font = [UIFont boldSystemFontOfSize:14];
        _signCountLabel.textColor = [UIColor blackColor];
        _signCountLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _signCountLabel;;
}

- (UICollectionView *)signProcessView{
    if (!_signProcessView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
        layout.minimumLineSpacing = 10 ;
        layout.minimumInteritemSpacing = 10;
        layout.itemSize = CGSizeMake(( KSCREEN_WIDTH - 40 - 30)/4.0, 138);
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _signProcessView  = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:layout];
        _signProcessView.backgroundColor = [UIColor whiteColor];
        [_signProcessView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:identify];
        _signProcessView.delegate = self;
        _signProcessView.dataSource = self;
    }
    return _signProcessView;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 4;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell =  [collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
    return cell;
}

@end
