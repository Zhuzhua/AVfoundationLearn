//
//  ViewController.h
//  XFAVFoundation
//
//  Created by xf-ling on 2017/6/19.
//  Copyright © 2017年 LXF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

